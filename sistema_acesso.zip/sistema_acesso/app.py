import os
import json
import re
import smtplib
import requests
import datetime
import cv2
import numpy as np
import easyocr
import base64
from ultralytics import YOLO
from werkzeug.utils import secure_filename
from email.mime.text import MIMEText
from flask import Flask, render_template, request, jsonify, redirect, url_for
from dotenv import load_dotenv
    
# Carregar variáveis de ambiente
load_dotenv()

app = Flask(__name__)

# --- CONFIGURAÇÕES ---
DB_PATH = os.getenv("DB_PATH", "db.json")
LOG_PATH = os.getenv("LOG_PATH", "logs.json")
ESP32_URL = os.getenv("ESP32_BASE_URL")
PLATE_REGEX = os.getenv("PLATE_REGEX", r"[A-Z]{3}\d{4}|[A-Z]{3}\d[A-Z]\d{2}")

# Configuração de Uploads
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Cria pasta de uploads se não existir
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Inicializa o leitor OCR (carrega na memória na inicialização para ser mais rápido depois)
# gpu=False se você não tiver placa de vídeo NVIDIA configurada (mais compatível)
print("Inicializando motor OCR (pode demorar um pouco)...")
# No seu app.py, altere a inicialização para:
try:
    reader = easyocr.Reader(['pt', 'en'], gpu=False, download_enabled=True)
except Exception as e:
    print(f"Erro ao carregar OCR: {e}")
print("Motor OCR pronto.")

# --- FUNÇÕES AUXILIARES ---

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def load_json(filepath, default_content):
    if not os.path.exists(filepath):
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(default_content, f, indent=2, ensure_ascii=False)
        return default_content
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except json.JSONDecodeError:
        return default_content

def save_json(filepath, data):
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def log_event(plate, qr_token, valid, action, source, reason=None):
    logs_data = load_json(LOG_PATH, {"logs": []})
    entry = {
        "timestamp": datetime.datetime.now().isoformat(),
        "plate": plate,
        "qr_token": qr_token,
        "valid": valid,
        "action": action,
        "source": source
    }
    if reason:
        entry["reason"] = reason
        
    logs_data["logs"].insert(0, entry)
    save_json(LOG_PATH, logs_data)

# --- FUNÇÕES DE VISÃO COMPUTACIONAL ---

def process_plate_image(image_path):
    """Lê imagem, converte para cinza e extrai texto via OCR"""
    try:
        # Carregar imagem com OpenCV
        img = cv2.imread(image_path)
        
        # Pré-processamento: Escala de Cinza
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Opcional: Aumentar contraste ou Binarização se necessário
        # _, binary = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)

        # Leitura OCR com EasyOCR
        result = reader.readtext(gray, detail=0) # detail=0 retorna apenas lista de strings
        
        # Unifica texto e busca padrão de placa
        full_text = "".join(result).upper().replace(" ", "").replace("-", "")
        
        # Tenta encontrar a placa no texto extraído usando Regex
        match = re.search(PLATE_REGEX, full_text)
        
        if match:
            return match.group(0)
        return None
    except Exception as e:
        print(f"Erro no OCR: {e}")
        return None

def process_qr_image(image_path):
    """Lê imagem e decodifica QR Code"""
    try:
        img = cv2.imread(image_path)
        detector = cv2.QRCodeDetector()
        data, bbox, _ = detector.detectAndDecode(img)
        
        if data:
            return data
        return None
    except Exception as e:
        print(f"Erro no QR Reader: {e}")
        return None

# --- COMUNICAÇÃO EXTERNA (Mantida igual) ---
# ... (Funções send_email_notification, trigger_esp32, get_esp32_status mantidas do código anterior) ...
# Vou resumir aqui para economizar espaço, mas use as mesmas funções do passo anterior.
def trigger_esp32(action):
    if not ESP32_URL: return False
    try:
        requests.post(f"{ESP32_URL}/act", json={"action": action}, timeout=2)
        return True
    except: return False

def get_esp32_status():
    if not ESP32_URL: return {"presence":False, "actuator":False, "error":"URL N/A"}
    try:
        r = requests.get(f"{ESP32_URL}/status", timeout=2)
        if r.status_code == 200: return r.json()
    except: pass
    return {"presence":False, "actuator":False, "error":"Off"}

def send_email_notification(plate, name, action, token):
    # (Use a mesma lógica do código anterior)
    pass

# --- ROTAS API PARA UPLOAD (AJAX) ---

@app.route('/api/scan_plate', methods=['POST'])
def api_scan_plate():
    if 'file' not in request.files:
        return jsonify({"error": "Nenhum arquivo enviado"}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "Nome vazio"}), 400
        
    if file and allowed_file(file.filename):
        filename = secure_filename(f"plate_{datetime.datetime.now().timestamp()}.jpg")
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        detected_plate = process_plate_image(filepath)
        
        # Log de escaneamento
        log_event(detected_plate if detected_plate else "DESCONHECIDO", "SCAN_IMG", False, "scan", "ocr", "image_upload")
        
        if detected_plate:
            return jsonify({"success": True, "plate": detected_plate})
        else:
            return jsonify({"success": False, "message": "Nenhuma placa válida identificada."})
            
    return jsonify({"error": "Formato inválido"}), 400

@app.route('/api/webcam_scan', methods=['POST'])
def api_webcam_scan():
    try:
        data = request.json
        header, encoded = data['image'].split(",", 1)
        img_bytes = base64.b64decode(encoded)
        nparr = np.frombuffer(img_bytes, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

        # IA detecta texto, posição E probabilidade (prob)
        # No app.py, dentro da função api_webcam_scan:
        results = reader.readtext(img)

        for (bbox, text, prob) in results:
            plate_text = "".join(text.split()).upper()
            
            # SÓ ENTRA AQUI SE TIVER MAIS DE 80% DE CERTEZA (prob > 0.8)
            if len(plate_text) >= 7 and prob > 0.80:
                x, y = int(bbox[0][0]), int(bbox[0][1])
                w, h = int(bbox[1][0] - x), int(bbox[2][1] - y)

                return jsonify({
                    "success": True, 
                    "plate": plate_text,
                    "coordinates": [x, y, w, h]
                })

        return jsonify({"success": False, "message": "Buscando nitidez..."})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/scan_qr', methods=['POST'])
def api_scan_qr():
    if 'file' not in request.files:
        return jsonify({"error": "Nenhum arquivo enviado"}), 400
    file = request.files['file']
    
    if file and allowed_file(file.filename):
        filename = secure_filename(f"qr_{datetime.datetime.now().timestamp()}.jpg")
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        qr_content = process_qr_image(filepath)
        
        # Log de escaneamento
        log_event("QR_SCAN", qr_content if qr_content else "ILEGIVEL", False, "scan", "ocr", "qr_upload")
        
        if qr_content:
            return jsonify({"success": True, "qr_token": qr_content})
        else:
            return jsonify({"success": False, "message": "QR Code não identificado na imagem."})
            
    return jsonify({"error": "Erro no upload"}), 400

# --- ROTAS NORMAIS ---

@app.route('/')
def index():
    db = load_json(DB_PATH, {"users": []})
    logs = load_json(LOG_PATH, {"logs": []})
    esp_status = get_esp32_status()
    return render_template('index.html', users=db['users'], logs=logs['logs'], esp_status=esp_status)

@app.route('/validate', methods=['POST'])
def validate():
    # Mesma lógica do passo anterior
    plate = request.form.get('plate', '').strip().upper()
    token = request.form.get('qr_token', '').strip()
    
    # Valida Regex
    if not re.fullmatch(PLATE_REGEX, plate):
        log_event(plate, token, False, "deny", "web", "invalid_format")
        trigger_esp32("close")
        return jsonify({"status": "error", "message": "Formato de placa inválido"})

    db = load_json(DB_PATH, {"users": []})
    user = next((u for u in db['users'] if u['plate'] == plate and u['qr_token'] == token), None)
    
    if user and user.get('active', True):
        log_event(plate, token, True, "open", "web")
        send_email_notification(plate, user['name'], "open", token)
        trigger_esp32("open")
        return jsonify({"status": "success", "message": f"Acesso LIBERADO: {user['name']}"})
    else:
        log_event(plate, token, False, "deny", "web", "auth_failed")
        send_email_notification(plate, "N/A", "deny", token)
        trigger_esp32("close")
        return jsonify({"status": "error", "message": "Acesso NEGADO: Dados incorretos ou usuário inativo"})

@app.route('/api/get_logs')
def get_logs():
    logs_data = load_json(LOG_PATH, {"logs": []})
    # Retorna os últimos 50 logs ordenados pelo mais recente
    return jsonify(logs_data['logs'][:50])

@app.route('/register', methods=['POST'])
def register():
    # Mesma lógica, mas retorna JSON para API fetch do frontend novo
    data = request.json
    plate = data.get('plate', '').strip().upper()
    qr_token = data.get('qr_token', '').strip()
    name = data.get('name', '')
    
    db = load_json(DB_PATH, {"users": []})
    # Check duplicidade
    if any(u['plate'] == plate or u['qr_token'] == qr_token for u in db['users']):
         return jsonify({"status": "error", "message": "Duplicidade encontrada"})
         
    db['users'].append({"name": name, "plate": plate, "qr_token": qr_token, "active": True})
    save_json(DB_PATH, db)
    return jsonify({"status": "success", "message": "Usuário cadastrado"})

@app.route('/delete_user', methods=['POST'])
def delete_user():
    try:
        data = request.json
        plate_to_delete = data.get('plate')
        
        db = load_json(DB_PATH, {"users": []})
        # Filtra a lista removendo o usuário
        db['users'] = [u for u in db['users'] if u['plate'] != plate_to_delete]
        
        save_json(DB_PATH, db)
        return jsonify({"status": "success", "message": "Usuário removido com sucesso"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/act', methods=['POST'])
def act():
    data = request.json
    trigger_esp32(data.get('action'))
    log_event("MANUAL", "ADMIN", True, data.get('action'), "web", "manual")
    return jsonify({"status": "ok"})

if __name__ == '__main__':
    load_json(DB_PATH, {"users": []})
    load_json(LOG_PATH, {"logs": []})
    app.run(host='0.0.0.0', port=5000, debug=True)